; (function ($) {

    // the available ease animation style
    var easeTypeArr = ['rollIn', 'fadeIn', 'fadeInUp', 'fadeInDown', 'fadeInLeft', 'fadeInRight', 'fadeInRight', 'bounceIn', 'bounceInDown', 'bounceInUp', 'bounceInLeft', 'bounceInRight', 'rotateIn', 'rotateInDownLeft', 'rotateInDownRight', 'rotateInUpLeft', 'rotateInUpRight', 'fadeInLeftBig', 'fadeInRightBig', 'fadeInUpBig', 'fadeInDownBig', 'flipInX', 'flipInY', 'lightSpeedIn'];
    var easeTypeNum = easeTypeArr.length;

    $.fn.oneByOne = function (options) {

        // plugin default options
        var settings = {
            className: 'oneByOne',
            sliderClassName: 'oneByOne_item',
            pauseByHover: false,
            easeType: 'fadeInLeft',
            width: 960,
            height: 420,
            minWidth: 480,
            delay: 300,
            tolerance: 0.25,
            enableDrag: true,
            showArrow: true,
            showButton: true,
            slideShow: false,
            slideShowDelay: 5000,
            responsive: false,
            autoHideButton: true
        };

        // extends settings with options provided
        if (options) {
            $.extend(settings, options);
        }

        var parent;
        var _this;
        var windowWidth = $(window).width();

        var currentBannerNum = -1;
        var getBannerWidth = parseInt(getComputedStyle(document.querySelector('.homeslider-inner .bgd')).width);
        var bannerWidth = getBannerWidth ? getBannerWidth : settings.width;
        var bannerHeight = settings.height;
        var _origWidth = bannerWidth;
        var _origHeight = bannerHeight;
        var xdiff = 0;
        var ydiff = 0;
        var isMovingHorizontal = false;
        var isMovingVertical = false;
        var isMouseDown = false;
        var isTweenning = false;
        // store the ease animation style of each slider
        var realEaseTypeArr = [];
        var _easeType;

        var bannerArr = [];
        var bannerNum = 0;
        var _preBannerNum = 0, buttonArea, buttonCon, arrowButton;
        var isPlaying = false;

        //settings for responsive progress bar
        var breakpointForProgressBar = 980;
        var isMobile = windowWidth < breakpointForProgressBar;
        // desktopProgressBar visible when 3 or more slides.
        var desktopProgressBarVisibleWhenSlides = 3;


        _this = this;
        _this.wrap('<div class="' + settings.className + '"/>');
        parent = _this.parent();

        parent.css('overflow', 'hidden');

        _this.find('.' + settings.sliderClassName).each(function (index) {
            /*
             if($(this).children().length>1){
             if(!($.browser.msie||$.browser.opera)){
             $(this).hide();
             }
             }
             */
            $(this).hide();
            bannerNum++;
            $(this).css('left', bannerWidth * index)
            bannerArr[index] = $(this);
        });
        if (bannerNum < 2) {
            document.body.classList.add('single-slide');
        }
        window.addEventListener('resize', () => {

            windowWidth = $(window).width();
            let currentBannerNumber = currentBannerNum < 0 ? 0 : currentBannerNum;

            if (isMobile !== windowWidth < breakpointForProgressBar && bannerNum >= desktopProgressBarVisibleWhenSlides) {
                stopSlideShow();
                displayButtons();
                isMobile = windowWidth < breakpointForProgressBar;

                var interval = setInterval(function () {
                    startSlideShow();
                    clearInterval(interval);
                }, settings.slideShowDelay / 1000);
            }

            getBannerWidth = parseInt(getComputedStyle(document.querySelector('.bgd')).width);
            bannerWidth = getBannerWidth ? getBannerWidth : settings.width;

            _this.find('.' + settings.sliderClassName).each(function (index) {
                $('.homeslider').css('left', -bannerWidth * currentBannerNumber);
                $(this).css('left', bannerWidth * index)
            });

        });

        // add the mobile touch screen support
        _this.bind('touchstart', function (event) {
            var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
            if (!isMouseDown) {
                isMouseDown = true;
                this.mouseX = touch.pageX;
                this.mouseY = touch.pageY;
            }
            if (arrowButton && _currentWidth > settings.minWidth) arrowButton.fadeIn();
            // return false;
            _this.addClass('touch-active');
        });

        _this.bind('touchmove', function (event) {
            var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
            if (isMouseDown) {
                xdiff = touch.pageX - this.mouseX;
                ydiff = touch.pageY - this.mouseY;
                if (!isMovingVertical && !isMovingHorizontal) {
                    if (ydiff > 10 || ydiff < -10) {
                        isMovingVertical = true;
                    }
                    if (xdiff > 10 || xdiff < -10) {
                        isMovingHorizontal = true;
                    }
                }
                if (isMovingHorizontal) {
                    event.preventDefault();
                    _this.css('left', -currentBannerNum * bannerWidth + xdiff);
                    if (settings.slideShow) {
                        stopSlideShow();
                    }
                }
                if (isMovingHorizontal) {
                    if (settings.slideShow) {
                        stopSlideShow();
                    }
                }
            }
        });

        _this.bind('touchend', function (event) {
            var _n = currentBannerNum;
            var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
            _this.removeClass('touch-active');
            isMouseDown = false;
            isMovingHorizontal = false;
            isMovingVertical = false;
            if (!xdiff) return false;
            var fullWidth = _currentWidth || parseInt(settings.width);
            var halfWidth = fullWidth / 2;
            if (-xdiff > halfWidth - fullWidth * settings.tolerance) {
                _n++;
                _n = _n >= bannerNum ? bannerNum - 1 : _n;
                tweenTo(_n);
            } else if (xdiff > halfWidth - fullWidth * settings.tolerance) {
                _n--;
                _n = _n < 0 ? 0 : _n;
                tweenTo(_n);
            } else {
                tweenTo(_n);
                if (settings.slideShow) {
                    startSlideShow();
                }
            }
            xdiff = 0;
            if (buttonCon) buttonCon.delay(400).fadeOut();
            if (arrowButton && settings.autoHideButton) arrowButton.delay(400).fadeOut();
            //return false;
        })

        // enable or disable the drag function of the slider
        if (settings.enableDrag) {
            _this.mousedown(function (event) {
                if (!isMouseDown) {
                    isMouseDown = true;
                    this.mouseX = event.pageX;
                }
                // return false;
            });

            _this.mousemove(function (event) {
                if (isMouseDown) {
                    xdiff = event.pageX - this.mouseX;
                    _this.css('left', -currentBannerNum * bannerWidth + xdiff);
                    if (settings.slideShow) {
                        stopSlideShow();
                    }

                }
                return false;
            });


            _this.mouseup(function (event) {
                isMouseDown = false;
                var _n = currentBannerNum;
                if (!xdiff) return false;
                var fullWidth = _currentWidth || parseInt(settings.width);
                var halfWidth = fullWidth / 2;
                if (-xdiff > halfWidth - fullWidth * settings.tolerance) {
                    _n++;
                    _n = _n >= bannerNum ? bannerNum - 1 : _n;
                    tweenTo(_n);

                } else if (xdiff > halfWidth - fullWidth * settings.tolerance) {
                    _n--;
                    _n = _n < 0 ? 0 : _n;
                    tweenTo(_n);
                } else {
                    tweenTo(_n);
                    if (settings.slideShow) {
                        startSlideShow();
                    }

                }
                xdiff = 0;
                return false;
            });

            _this.mouseleave(function (event) {
                $(this).mouseup();
            });

        }

        parent.mouseover(function (event) {
            if (arrowButton && _currentWidth > settings.minWidth) arrowButton.fadeIn();
            if (settings.pauseByHover) {
                stopSlideShow();
                isPlaying = false;
            }
        });

        parent.mouseleave(function (event) {
            if (arrowButton && settings.autoHideButton) arrowButton.fadeOut();
            if (settings.pauseByHover && settings.slideShow) {
                startSlideShow();
                isPlaying = true;
            }
        });

        // add the circle buttons
        if (settings.showButton) {
            displayButtons();
        }

        // add the previous/next arrow buttons
        if (settings.showArrow) {
            arrowButton = $('<div class="arrowButton"><div class="prevArrow"></div><div class="nextArrow"></div></div>');
            parent.append(arrowButton);
            var _next = $('.nextArrow', arrowButton).bind('click', function (event) {
                nextBanner();
            });
            var _prev = $('.prevArrow', arrowButton).bind('click', function (event) {
                prevBanner();
            });

        }

        if (buttonCon) buttonCon.hide();
        if (arrowButton && settings.autoHideButton) arrowButton.hide();

        tweenTo(0);

        if (settings.slideShow) {
            slideShowInt = setInterval(function () {
                nextBanner();
            }, settings.slideShowDelay);
            _this.data('interval', slideShowInt);
            isPlaying = true;
        }

        // move to the certain slider via a number, display the slider content one by one
        function tweenTo(n) {
            stopSlideShow();
            if (settings.slideShow) {
                stopSlideShow();
            }

            _this.stop(true, true).animate({
                left: -n * bannerWidth
            }, settings.delay, function () {

                if (n != currentBannerNum) {
                    _preBannerNum = currentBannerNum;
                    if (bannerArr[_preBannerNum]) {
                        bannerArr[_preBannerNum].fadeOut();
                        $('.buttonMobileArea').removeClass('black');
                        $('.arrowButton').removeClass('black');
                        $('.buttonMobileArea .buttonCon .progressButton:eq(' + _preBannerNum + ')', parent).removeClass('active');
                        $('.buttonMobileArea').removeClass('activeBanner' + _preBannerNum);
                    }

                    $('.buttonMobileArea .buttonCon .progressButton:eq(' + n + ')', parent).addClass('active');
                    $('.buttonMobileArea').addClass('activeBanner' + n);

                    if (bannerArr[n].hasClass('black-navigation-mobile') && windowWidth <= 520 || bannerArr[n].hasClass('black-navigation-desktop') && windowWidth > 520) {
                        $('.buttonMobileArea').addClass('black');
                        $('.arrowButton').addClass('black');
                    }

                    if (bannerNum >= desktopProgressBarVisibleWhenSlides && windowWidth >= breakpointForProgressBar) {
                        bottomSliderAnimation(n);
                    }

                    if (settings.easeType.toLowerCase() != "random") {
                        bannerArr[n].show().children().each(function (index) {
                            var _n = index;
                            var _item = $(this);
                            var _existClass = "";
                            var _isClassed = false;

                            if ($(this).hasClass(settings.easeType)) {
                                $(this).removeClass(settings.easeType);
                                $(this).hide();
                            }

                            if (_item.data('animate')) {
                                _isClassed = true;
                                _existClass = _item.data('animate');
                                _item.removeClass(_existClass);
                                _item.hide();
                            }

                            if (_isClassed) {
                                _item.show().addClass("animate" + _n + " " + _existClass);
                            } else {
                                _item.show().addClass("animate" + _n + " " + settings.easeType);
                            }
                            if (settings.responsive && _currentWidth < settings.minWidth && !$(this).is('img')) _item.hide();

                        });
                    } else {

                        _easeType = easeTypeArr[Math.floor(Math.random() * easeTypeNum)];
                        realEaseTypeArr[n] = _easeType;
                        if (bannerArr[_preBannerNum]) {
                            bannerArr[_preBannerNum].children().each(function (index) {
                                if ($(this).hasClass(realEaseTypeArr[_preBannerNum])) {
                                    $(this).removeClass(realEaseTypeArr[_preBannerNum]);
                                    $(this).hide();
                                }
                            });

                        }


                        bannerArr[n].show().children().each(function (index) {
                            var _n = index;
                            var _item = $(this);
                            var _existClass = "";
                            var _isClassed = false;
                            if (_item.data('animate')) {
                                _isClassed = true;
                                // _existClass = easeTypeArr[index];
                                _existClass = _item.data('animate');
                                _item.removeClass(_existClass);
                                _item.hide();
                            }

                            if (_isClassed) {
                                _item.show().addClass("animate" + _n + " " + _existClass);
                            } else {
                                _item.show().addClass("animate" + _n + " " + _easeType);
                            }
                            // hidden the text block when screen is smaller than minWidth
                            if (settings.responsive && _currentWidth < settings.minWidth && !$(this).is('img')) _item.hide();

                        });
                    }

                    // isTweenning = false;
                    _this.delay(bannerArr[n].children().length * 200).queue(function () {
                        if (settings.slideShow && isPlaying) startSlideShow();
                    })
                    if (arrowButton) arrowButton.css('cursor', 'pointer');
                    currentBannerNum = n;
                }
            });
        }

        var _currentWidth = _this.parent().width();
        if (settings.responsive) {
            /* for webkit browser to get the size to detect to show the text or not */
            _this.parent().css('height', _origHeight * _currentWidth / _origWidth);
            $(window).load(updateResponsive);
            $(window).resize(updateResponsive);
        }

        isInViewport();
        $(window).on('scroll touchmove', function () {
            isInViewport();
        });

        function isInViewport() {
            var $slider = $(_this),
                windowTop = $(window).scrollTop(),
                windowBottom = windowTop + $(window).height(),
                sliderTop = $slider.offset().top,
                sliderBottom = sliderTop + $slider.height(),
                isVisible = (windowBottom >= sliderTop && windowTop <= sliderBottom);

            if (!isVisible) {
                if (isPlaying) {
                    stopSlideShow();
                    isPlaying = false;
                }
            } else {
                if (!isPlaying) {
                    startSlideShow();
                    isPlaying = true;
                }
            }
        }

        function updateResponsive(event) {
            _currentWidth = _this.parent().width();
            _this.parent().css('height', _origHeight * _currentWidth / _origWidth);
            _this.find('.' + settings.sliderClassName).each(function (index) {
                $(this).css('height', _origHeight * _currentWidth / _origWidth);
                if (_currentWidth < settings.minWidth) {
                    $(this).find('span').css('display', 'none');
                    arrowButton.css('display', 'none');
                } else {
                    $(this).find('span').css('display', '');
                    arrowButton.css('display', '');
                }
            });

            if (_next) {
                _next.css('top', _origHeight * _currentWidth / _origWidth * .5 - 40);
            }
            if (_prev) {
                _prev.css('top', _origHeight * _currentWidth / _origWidth * .5 - 40);
            }
        }

        function displayButtons() {
            let activeBannerNum = currentBannerNum < 0 ? 0 : currentBannerNum;

            if (bannerNum < desktopProgressBarVisibleWhenSlides || windowWidth < breakpointForProgressBar) {
                mobileButtons();
                $('.bottomSliderArea').remove();

                $('.buttonCon .progressButton').bind('click', function (event) {
                    if ($(this).hasClass('active')) return false;
                    var _n = $(this).attr('rel');
                    tweenTo(_n);
                });

                const duration = (settings.slideShowDelay / 1000) + "s";
                $('.progress-circle').css('animationDuration', duration);

                $('.buttonMobileArea .buttonCon .progressButton:eq(' + activeBannerNum + ')').addClass('active');
            } else {
                desktopButtons();
                $('.buttonMobileArea').remove();

                $('.buttonCon a').bind('click', function (event) {
                    if ($(this).hasClass('active')) return false;
                    var _n = $(this).attr('rel');
                    tweenTo(_n);
                });

                bottomSliderAnimation(activeBannerNum);
            }

        }

        function mobileButtons() {
            buttonArea = $('<div class="buttonMobileArea"><div class="buttonCon"></div></div>');
            parent.append(buttonArea);
            buttonCon = buttonArea.find('.buttonCon');

            for (var i = 0; i < bannerNum; i++) {
                buttonCon.append('<div class="progressButton" rel="' + i + '"><svg class="progress" width="30" height="30"><circle class="progress-circle" cx="15" cy="15" r="12" stroke-width="1" fill="transparent" stroke="#fff"/></svg><div class="theButton">' + (i + 1) + '</div></div>').css('cursor', 'pointer');
            }
        }

        function desktopButtons() {
            $('.homeslider-wrapper').after('<div class="bottomSliderArea"><div class="buttonArea"> <div class="bottomSliderProgressCon"></div> <div class="buttonCon"></div></div></div>');
            buttonArea = $('.bottomSliderArea');
            buttonCon = buttonArea.find('.buttonCon');

            if (bannerNum <= 3) {
                buttonArea.width("870px");
            } else {
                buttonArea.width("920px");
            }


            for (var i = 0; i < bannerNum; i++) {
                let buttonLable = $('.item-0' + (1 + i)).data("slider-lable");
                if (i !== bannerNum - 1) {
                    buttonCon.append('<a class="theButton" rel="' + i + '"><span>' + buttonLable + '</span><div class="verticalLine"></div></a>').css('cursor', 'pointer');
                } else {
                    buttonCon.append('<a class="theButton" rel="' + i + '"><span>' + buttonLable + '</span></a>').css('cursor', 'pointer');
                }
            }
        }

        function stopSlideShow() {
            clearInterval(_this.data('interval'));
        }

        function startSlideShow() {
            clearInterval(_this.data('interval'));
            slideShowInt = setInterval(function () {
                nextBanner();
            }, settings.slideShowDelay);
            _this.data('interval', slideShowInt);
        }

        function nextBanner() {
            var _n = currentBannerNum;
            _n++;
            _n = _n >= bannerNum ? 0 : _n;
            tweenTo(_n);
        }

        function prevBanner() {
            var _n = currentBannerNum;
            _n--;
            _n = _n < 0 ? bannerNum - 1 : _n;
            tweenTo(_n);
        }

        function bottomSliderAnimation(currentBanner) {

            let animationDuration = settings.slideShowDelay;
            currentBanner = parseInt(currentBanner);

            let buttonWidth = 100 / bannerNum;
            let startWidth = buttonWidth * currentBanner;
            startWidth = startWidth < 0 ? 0 : startWidth;
            let endWidth = startWidth + buttonWidth;
            endWidth = endWidth > 100 ? 100 : endWidth;

            if (currentBanner === bannerNum) {
                startWidth = 0;
                endWidth = buttonWidth;
            }

            if (currentBanner < 0) {
                endWidth = 100;
                startWidth = 75;
            }

            $('.bottomSliderProgressCon').stop(true).width();
            $('.bottomSliderProgressCon').css('width', startWidth + '%');
            $('.bottomSliderProgressCon').animate({
                width: endWidth + '%'
            }, animationDuration, 'linear');
        }

        return this;
    };
})(jQuery);
